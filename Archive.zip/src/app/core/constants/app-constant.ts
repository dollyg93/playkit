export class AppConstant {
    public static USER(): number {
        return 1;
    };

    public static CLASS(): number {
        return 2;
    };

    public static SCHOOL(): number {
        return 3;
    };

    public static REGION(): number {
        return 4;
    };

    public static COUNTRY(): number {
        return 5;
    };

    public static ADDUSER(): string {
        return 'ADD USER';
    };

    public static ADDCLASS(): string {
        return 'ADD CLASS';
    };

    public static ADDSCHOOL(): string {
        return 'ADD SCHOOL';
    };

    public static ADDREGION(): string {
        return 'ADD REGION';
    };

    public static ADDCOUNTRY(): string {
        return 'ADD COUNTRY';
    };
}