import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-class-add',
    templateUrl: 'class-add.component.html'
})

export class ClassAddComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}