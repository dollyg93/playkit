import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ClassEditComponent } from './class-edit.component';

const routes: Routes = [
  {
    path: '',
    component: ClassEditComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ClassEditRoutingModule { }
