import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-class-edit',
    templateUrl: 'class-edit.component.html'
})

export class ClassEditComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}