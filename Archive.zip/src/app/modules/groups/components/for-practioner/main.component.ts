import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-group-practioner',
    templateUrl: 'main.component.html'
})

export class PractionerGroupMainComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}