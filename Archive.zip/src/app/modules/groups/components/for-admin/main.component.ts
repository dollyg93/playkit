import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-group-admin',
    templateUrl: './main.component.html'
})

export class AdminGroupMainComponent implements OnInit {
    clicked: string;

    constructor() { }

    ngOnInit() { }
}