import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-filter-list',
    templateUrl: 'filter.component.html'
})

export class FilterComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}