import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-user-list',
    templateUrl: 'list.component.html'
})

export class ListComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}