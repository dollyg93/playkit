import { Component, OnInit } from '@angular/core';
import {AppConstant} from '@core/constants/app-constant';
@Component({
    selector: 'app-users',
    templateUrl: 'users.component.html'
})

export class UsersComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}