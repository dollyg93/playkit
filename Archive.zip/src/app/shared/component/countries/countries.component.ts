import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-countries',
    templateUrl: 'countries.component.html'
})

export class CountriesComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}