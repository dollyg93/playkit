import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-schools',
    templateUrl: 'schools.component.html'
})

export class SchoolsComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}