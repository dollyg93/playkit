import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-regions',
    templateUrl: 'regions.component.html'
})

export class RegionsComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}