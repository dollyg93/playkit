export interface Project {
  id: number;
  link: string;
  title: string;
  thumbnail: string;
  description: string;
}
